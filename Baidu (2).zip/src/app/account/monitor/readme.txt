  // searchResult = [{
  //   area: "",
  //   city: "",
  //   detail: "",
  //   location: {
  //     lat: "",
  //     lng: ""
  //   },
  //   name: "",
  //   province: "",
  //   uid: "",
  // }
  // ];

    //progressBarStatus
  // progressStatus = "buffer"; //query, determinate
  // progressValue = 0;
