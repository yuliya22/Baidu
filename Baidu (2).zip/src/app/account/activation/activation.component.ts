import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-activation',
  templateUrl: './activation.component.html',
  styleUrls: ['./activation.component.scss']
})
export class ActivationComponent implements OnInit {
	// formGroup: FormGroup;
  // constructor(private _formBuilder: FormBuilder) { }

  ngOnInit() {
    // this.formGroup = this._formBuilder.group({
    //   PlateNumber: ['', Validators.required],
    //   DriverName: ['', Validators.required],
    //   Country: ['', Validators.required],
    //   Group: ['', Validators.required],
		// 	Category: ['', Validators.required],
		// 	EngineType: ['', Validators.required],
		// 	VIN: ['', Validators.required],
		// 	Time: ['', Validators.required],
		// 	cardName: ['', Validators.required],
		// 	cardNumber: ['', Validators.required],
		// 	ExpirationDate: ['', Validators.required],
    //   SecurityCode: ['', Validators.required],
    //   AutoRenew:['', Validators.required],
		// });
  }

}
