const mongoose = require('mongoose');
const passport = require('passport');
const _ = require('lodash');

const Vehicle = mongoose.model('Vehicle');
module.exports.getInfo = (req, res, next) =>{
    console.log('ddd');
    Vehicle.findOne({ auth: req.auth },
        (err, data) => {
            if (!data)
                return res.status(404).json({ status: false, message: 'Vehicle record not found.' });
            else
                return res.status(200).json({ status: true, result:data});
        }
    );
}
