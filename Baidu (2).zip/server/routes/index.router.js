const express = require('express');
const router = express.Router();

const ctrlUser = require('../controllers/user.controller');
const jwtHelper = require('../config/jwtHelper');
//vehicle
const ctrlVehicle = require('../controllers/vehicle.controller');
//user
router.post('/register', ctrlUser.register);
router.post('/authenticate', ctrlUser.authenticate);
router.get('/userProfile',jwtHelper.verifyJwtToken, ctrlUser.userProfile);
//vehicle
router.post('/vehicle/getInfo', ctrlVehicle.getInfo);
module.exports = router;



