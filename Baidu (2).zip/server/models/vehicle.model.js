const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

var vehicleSchema = new mongoose.Schema({
    auth: {
        type: String,
        required: 'Email can\'t be empty',
        unique: true
    },
    vehicleNumber: {
       type: Array,
       required: true
    }
});
mongoose.model('Vehicle', vehicleSchema);
