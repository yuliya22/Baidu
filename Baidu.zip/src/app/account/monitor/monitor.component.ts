import { QueryLocation } from './../../shared/mapService/queryLocation.model';
import { MapService } from './../../shared/mapService/map.service';
import { Component, OnInit, DoCheck} from '@angular/core';
import {
  ControlAnchor,
  MapOptions,
  NavigationControlOptions,
  NavigationControlType,
  Point,
  Marker,
  BMarker,
  BMapInstance,
  MarkerOptions,
  Animation,
} from 'angular2-baidu-map';
@Component({
  selector: 'app-monitor',
  templateUrl: './monitor.component.html',
  styleUrls: ['./monitor.component.css']
})
export class MonitorComponent implements OnInit {
  //Map_Settings
  title = 'angular5 Baidu-Map example';
  region = 'Beijing';
  enableMap = false ;
  optionsMap: MapOptions;
  mapControl: BMapInstance;
  point: Point;
  navOptionsMap: NavigationControlOptions;
  markers: Array<{ point?: Point; options?: MarkerOptions }>;
  markerOption = {
    icon: {
      imageUrl: `assets/images/markericon.png`,
      size: {
        height: 35,
        width: 25
      },
      imageSize: {
        height: 35,
        width: 25
      }
    }
  };
  query: QueryLocation ={
    query:'',
    region:'',
  };
  //SearchBar_Settings
  selectedItem = "";
  searchResult = [];
  //selectionTable_Settings.
  foundedItem = [];
  selectionStatus = [];
  selectAll = false;
  constructor(
    private mapService: MapService,
  ) {
    this.query.region=this.region;
    this.optionsMap = {
      centerAndZoom: {
        lat: 39.912695,
        lng: 116.502814,
        zoom: 17,
      },
      enableKeyboard: true,
      enableScrollWheelZoom: true,
    };
    this.markers = [];
    this.navOptionsMap = {
      anchor: ControlAnchor.BMAP_ANCHOR_TOP_RIGHT,
      type: NavigationControlType.BMAP_NAVIGATION_CONTROL_ZOOM,
    };
   }
ngOnInit(){
}
//For searchResult
getMonitorSeachlist(){

  this.mapService.locationSearch(this.query).subscribe(
    res=>{
       if(res["results"].length){
          this.searchResult=res["results"];
       }
    },
    err=>{
       console.log(err);
    }
  );
}
searchConfirm(){
  if(this.searchResult.length>0){
    this.setMap(this.searchResult[0]);
  }
}
//For selection table
checkBoxall(){
    this.checkSetAll(this.selectAll);
}
checkSetAll(status) {
  for(let i=0;i<this.selectionStatus.length;i++){
    this.selectionStatus[i]=status;
  }
}
//For Maps
mapLoaded(e:BMapInstance){
  this.enableMap = true;
  this.mapControl = e;
}
setMap(opt){
  const newMarker = {
    options:this.markerOption,
    point: {
      lat: opt.location.lat,
      lng: opt.location.lng,
    }
  };
   this.selectionStatus.unshift(true);
   this.markers.unshift(newMarker);
   this.foundedItem.unshift(opt);
   this.selectAll = true;
   this.searchResult = [];
   this.setZoomAndCenter(opt);
}
setZoomAndCenter(opt){
  if(this.markers.length==0) return;
  const center = {
   lat:opt.location.lat,
   lng:opt.location.lng,
   equals:Boolean,
  };
  const x = this.mapControl.pointToPixel(center).x/this.optionsMap.centerAndZoom.zoom;
  const y = this.mapControl.pointToPixel(center).y/this.optionsMap.centerAndZoom.zoom;
  // console.log([x,y]);
  // console.log(center);
  // this.mapControl.panBy(x,y,{noAnimation:false});
  this.mapControl.centerAndZoom(center,10);
  this.mapControl.setZoom(10);
}
setAnimation(marker: BMarker): void {
  // marker.setAnimation(Animation.BMAP_ANIMATION_BOUNCE);
}
showWindow({
             marker,
             map
           }: {
  marker: BMarker
  map: BMapInstance
}): void {
  map.openInfoWindow(
    new window.BMap.InfoWindow('地址：浦东南路360号', {
      offset: new window.BMap.Size(0, -30),
      title: '新上海国际大厦'
    }),
    marker.getPosition()
  );
}
}

