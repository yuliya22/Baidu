export class QueryLocation {
    query: string;
    region: string;
}
